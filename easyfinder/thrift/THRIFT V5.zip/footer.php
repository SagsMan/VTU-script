   <!-- partial:partials/_footer.html -->
   <div class="row">
   <div class="col-12">
        <footer class="footer">
          <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2008-<?php echo getDate_(); ?> <a href="" target="_blank"><?php echo APP_FULLNAME;?></a>. All rights reserved.</span>
            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with <i class="mdi mdi-heart text-danger"></i></span>
          </div>
        </footer>
   </div>
   </div>
        <!-- partial -->